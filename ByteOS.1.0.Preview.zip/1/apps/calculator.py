import curses
# apps/calculator.py
def run(stdscr):
    curses.echo()
    stdscr.clear()
    stdscr.addstr(0, 0, "Calculator - Type expression or 'exit'")
    while True:
        stdscr.addstr(2, 0, ">> ")
        expr = stdscr.getstr(2, 3, 40).decode()
        if expr.lower() == "exit":
            break
        try:
            result = eval(expr)
            stdscr.addstr(4, 0, f"Result: {result}      ")
        except Exception as e:
            stdscr.addstr(4, 0, f"Error: {e}      ")
        stdscr.refresh()
