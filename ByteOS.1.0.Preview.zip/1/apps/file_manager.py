# file_manager.py
import os
import curses
import pyperclip

def detect_type(path):
    if os.path.isdir(path):
        return 'folder'
    ext = os.path.splitext(path)[1]
    return {
        '.txt': 'text file',
        '.py': 'python file',
        '.jpg': 'image file',
        '.png': 'image file',
        '.md': 'markdown file',
        '.exe': 'executable',
    }.get(ext, 'unknown')

def draw_ui(stdscr, current_path, files, selected, mode, button_index, buttons):
    stdscr.clear()
    curses.init_pair(1, curses.COLOR_CYAN, curses.COLOR_BLACK)
    curses.init_pair(2, curses.COLOR_BLACK, curses.COLOR_WHITE)

    # Header{"label": "File Manager", "desc": "Browse files", "action": file_manager.run}
    stdscr.addstr(0, 0, f"file manager | {current_path}", curses.color_pair(1))

    # Button row
    stdscr.addstr(1, 0, "-" * 60)
    button_line = ""
    for i, btn in enumerate(buttons):
        if mode == "buttons" and i == button_index:
            button_line += f"[{btn.upper()}]   "
        else:
            button_line += f"[ {btn} ]   "
    stdscr.addstr(2, 0, button_line.strip())
    stdscr.addstr(3, 0, "-" * 60)

    # File list
    for idx, name in enumerate(files):
        path = os.path.join(current_path, name)
        file_type = detect_type(path)
        prefix = "→ " if mode == "files" and idx == selected else "  "
        stdscr.addstr(4 + idx, 0, f"{prefix}{name:<40} | {file_type}")

    stdscr.refresh()

def file_manager(stdscr):
    curses.curs_set(0)
    current_path = os.getcwd()
    selected = 0
    mode = "files"
    button_index = 0
    buttons = ["go back", "copy path", "exit"]

    while True:
        files = os.listdir(current_path)
        draw_ui(stdscr, current_path, files, selected, mode, button_index, buttons)

        key = stdscr.getch()

        if mode == "files":
            if key == curses.KEY_UP and selected > 0:
                selected -= 1
            elif key == curses.KEY_DOWN and selected < len(files) - 1:
                selected += 1
            elif key == ord('\n'):
                chosen = os.path.join(current_path, files[selected])
                if os.path.isdir(chosen):
                    current_path = chosen
                    selected = 0
                else:
                    stdscr.clear()
                    try:
                        with open(chosen, 'r') as f:
                            content = f.read()
                        stdscr.addstr(0, 0, content[:1000])
                    except Exception as e:
                        stdscr.addstr(0, 0, f"Error opening file: {e}")
                    stdscr.getch()
            elif key == ord('e'):
                mode = "buttons"
                button_index = 0
            elif key == ord('b'):
                current_path = os.path.dirname(current_path)
                selected = 0
            elif key == ord('c'):
                pyperclip.copy(current_path)
            elif key == ord('q'):
                break

        elif mode == "buttons":
            if key == curses.KEY_LEFT and button_index > 0:
                button_index -= 1
            elif key == curses.KEY_RIGHT and button_index < len(buttons) - 1:
                button_index += 1
            elif key == ord('\n'):
                action = buttons[button_index]
                if action == "go back":
                    current_path = os.path.dirname(current_path)
                    selected = 0
                elif action == "copy path":
                    pyperclip.copy(current_path)
                elif action == "exit":
                    break
                mode = "files"
            elif key == 27:  # ESC key
                mode = "files"

def run(stdscr):
    file_manager(stdscr)


if __name__ == "__main__":
    curses.wrapper(file_manager)
