# apps/plugin_manager.py
import curses
import os
import json
import importlib.util

PLUGIN_DIR = "plugins"
REGISTRY_PATH = os.path.join(PLUGIN_DIR, "registry.json")

def load_registry():
    if not os.path.exists(REGISTRY_PATH):
        return {"installed": []}
    with open(REGISTRY_PATH, "r") as f:
        return json.load(f)

def save_registry(registry):
    with open(REGISTRY_PATH, "w") as f:
        json.dump(registry, f, indent=2)

def load_plugins():
    plugins = []
    for fname in os.listdir(PLUGIN_DIR):
        if fname.endswith(".py") and fname != "__init__.py":
            path = os.path.join(PLUGIN_DIR, fname)
            spec = importlib.util.spec_from_file_location(fname[:-3], path)
            mod = importlib.util.module_from_spec(spec)
            try:
                spec.loader.exec_module(mod)
                plugins.append({
                    "id": getattr(mod, "PLUGIN_ID", fname[:-3]),
                    "name": getattr(mod, "PLUGIN_NAME", fname[:-3]),
                    "desc": getattr(mod, "PLUGIN_DESC", ""),
                    "file": fname
                })
            except Exception as e:
                plugins.append({
                    "id": fname[:-3],
                    "name": fname[:-3],
                    "desc": f"Error loading plugin: {e}",
                    "file": fname
                })
    return plugins

def run(stdscr):
    curses.curs_set(0)
    registry = load_registry()
    plugins = load_plugins()
    selected = 0

    while True:
        stdscr.clear()
        stdscr.addstr(0, 0, "Plugin Manager - Select to Install/Uninstall (ESC to exit)")
        for i, plugin in enumerate(plugins):
            status = "[Installed]" if plugin["id"] in registry["installed"] else "[Not Installed]"
            line = f"{plugin['name']} {status}"
            if plugin["desc"]:
                line += f" - {plugin['desc']}"
            mode = curses.A_REVERSE if i == selected else curses.A_NORMAL
            stdscr.addstr(i + 2, 2, line[:curses.COLS - 4], mode)

        key = stdscr.getch()
        if key == curses.KEY_UP:
            selected = (selected - 1) % len(plugins)
        elif key == curses.KEY_DOWN:
            selected = (selected + 1) % len(plugins)
        elif key in [10, 13]:  # Enter
            plugin_id = plugins[selected]["id"]
            if plugin_id in registry["installed"]:
                registry["installed"].remove(plugin_id)
            else:
                registry["installed"].append(plugin_id)
            save_registry(registry)
        elif key == 27:  # ESC
            break
