# apps/text_editor.py
import curses
import os

def run(stdscr, filepath="untitled.txt"):
    editor(stdscr, filepath)

def editor(stdscr, filepath):
    curses.start_color()
    curses.init_pair(1, curses.COLOR_BLACK, curses.COLOR_CYAN)

    curses.curs_set(1)
    max_y, max_x = stdscr.getmaxyx()
    filename = os.path.basename(filepath)

    try:
        with open(filepath, 'r') as f:
            lines = f.read().splitlines()
    except FileNotFoundError:
        lines = ['']

    if not lines:
        lines = ['']

    cursor_y, cursor_x = 0, 0
    status_msg = "Ctrl+F Save | Ctrl+X Exit"
    saved = True

    while True:
        stdscr.clear()

        # Header
        header = f"textbyte - editing: {filename}"
        header += " (Saved)" if saved else " (Unsaved changes)"
        stdscr.attron(curses.color_pair(1))
        stdscr.addstr(0, 0, header[:max_x - 1])
        stdscr.attroff(curses.color_pair(1))

        # Text area
        for idx, line in enumerate(lines):
            if idx < max_y - 2:
                stdscr.addstr(idx + 1, 0, line[:max_x - 1])

        # Status bar
        stdscr.attron(curses.color_pair(1))
        stdscr.addstr(max_y - 1, 0, status_msg.ljust(max_x - 1))
        stdscr.attroff(curses.color_pair(1))

        stdscr.move(cursor_y + 1, cursor_x)
        stdscr.refresh()

        key = stdscr.getch()

        if key == curses.KEY_UP:
            cursor_y = max(0, cursor_y - 1)
            cursor_x = min(len(lines[cursor_y]), cursor_x)
        elif key == curses.KEY_DOWN:
            cursor_y = min(len(lines) - 1, cursor_y + 1)
            cursor_x = min(len(lines[cursor_y]), cursor_x)
        elif key == curses.KEY_LEFT:
            cursor_x = max(0, cursor_x - 1)
        elif key == curses.KEY_RIGHT:
            cursor_x = min(len(lines[cursor_y]), cursor_x + 1)
        elif key in (curses.KEY_BACKSPACE, 127):
            if cursor_x > 0:
                lines[cursor_y] = lines[cursor_y][:cursor_x - 1] + lines[cursor_y][cursor_x:]
                cursor_x -= 1
                saved = False
            elif cursor_y > 0:
                cursor_x = len(lines[cursor_y - 1])
                lines[cursor_y - 1] += lines[cursor_y]
                del lines[cursor_y]
                cursor_y -= 1
                saved = False
        elif key == 10:  # Enter
            rest = lines[cursor_y][cursor_x:]
            lines[cursor_y] = lines[cursor_y][:cursor_x]
            lines.insert(cursor_y + 1, rest)
            cursor_y += 1
            cursor_x = 0
            saved = False
        elif key == 24:  # Ctrl+X
            break
        elif key == 6:  # Ctrl+F
            with open(filepath, 'w') as f:
                f.write('\n'.join(lines))
            saved = True
            status_msg = f"Saved {filename}! Ctrl+F Save | Ctrl+X Exit"
        elif 32 <= key <= 126:
            while cursor_y >= len(lines):
                lines.append('')
            line = lines[cursor_y]
            lines[cursor_y] = line[:cursor_x] + chr(key) + line[cursor_x:]
            cursor_x += 1
            saved = False
