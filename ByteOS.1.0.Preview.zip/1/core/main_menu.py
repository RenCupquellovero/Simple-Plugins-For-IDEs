import curses
import os
import json
import importlib.util

from apps import text_editor, file_manager, calculator, plugin_manager

PLUGIN_DIR = "plugins"
REGISTRY_PATH = os.path.join(PLUGIN_DIR, "registry.json")

def load_registry():
    if not os.path.exists(REGISTRY_PATH):
        return {"installed": []}
    with open(REGISTRY_PATH, "r") as f:
        return json.load(f)

def load_installed_plugins():
    registry = load_registry()
    plugins = []
    for fname in os.listdir(PLUGIN_DIR):
        if fname.endswith(".py") and fname != "__init__.py":
            path = os.path.join(PLUGIN_DIR, fname)
            spec = importlib.util.spec_from_file_location(fname[:-3], path)
            mod = importlib.util.module_from_spec(spec)
            try:
                spec.loader.exec_module(mod)
                plugin_id = getattr(mod, "PLUGIN_ID", fname[:-3])
                if plugin_id in registry["installed"]:
                    plugins.append({
                        "label": getattr(mod, "PLUGIN_NAME", fname[:-3]),
                        "desc": getattr(mod, "PLUGIN_DESC", ""),
                        "action": lambda stdscr, m=mod: m.run(stdscr)
                    })
            except:
                continue
    return plugins

def show_about(stdscr):
    stdscr.clear()
    stdscr.addstr(0, 0, "ByteOS - Terminal Operating Shell")
    stdscr.addstr(2, 0, "Created by RenCup")
    stdscr.addstr(4, 0, "Press any key to return")
    stdscr.refresh()
    stdscr.getch()

def launch_textbyte(stdscr):
    curses.echo()
    stdscr.clear()
    stdscr.addstr(0, 0, "📄 Enter the path to the file you want to edit:")
    stdscr.refresh()
    path = stdscr.getstr(2, 0, 100).decode("utf-8").strip()
    curses.noecho()

    if not path:
        stdscr.addstr(4, 0, "⚠️ No path entered. Press any key to return.")
        stdscr.getch()
        return

    try:
        text_editor.run(stdscr, path)
    except Exception as e:
        stdscr.clear()
        stdscr.addstr(0, 0, f"💥 Error opening file: {e}")
        stdscr.addstr(2, 0, "Press any key to return.")
        stdscr.getch()

def run_main_menu(stdscr):
    curses.curs_set(0)
    stdscr.clear()
    selected = 0

    while True:
        # Rebuild sections and plugin list every time
        sections = [
            {
                "title": "Apps",
                "items": [
                    {"label": "TextByte", "desc": "Edit any file", "action": launch_textbyte},
                    {"label": "Calculator", "desc": "Crunch numbers", "action": calculator.run},
                    {"label": "File Manager", "desc": "Browse files", "action": file_manager.run}
                ]
            },
            {
                "title": "Settings",
                "items": [
                    {"label": "About", "desc": "System info", "action": show_about},
                    {"label": "Plugin Manager", "desc": "Manage extensions", "action": plugin_manager.run},
                    {"label": "🔄 Refresh Plugins", "desc": "Reload plugin list", "action": lambda s: None}
                ]
            },
            {
                "title": "Plugins",
                "items": load_installed_plugins()
            }
        ]

        flat_items = []
        for section in sections:
            flat_items.extend(section["items"])
        flat_items.append({"label": "Exit", "desc": "Close ByteOS", "action": lambda s: exit(0)})

        stdscr.clear()
        stdscr.addstr(0, 0, "ByteOS")
        stdscr.addstr(1, 0, "-" * curses.COLS)

        row = 3
        index = 0
        for section in sections:
            stdscr.addstr(row, 0, section["title"])
            stdscr.addstr(row + 1, 0, "-" * curses.COLS)
            row += 2
            for item in section["items"]:
                mode = curses.A_REVERSE if index == selected else curses.A_NORMAL
                label = f"[ {item['label']:<13} ]"
                desc = item.get("desc", "")
                stdscr.addstr(row, 2, label, mode)
                stdscr.addstr(row, 20, desc, mode)
                row += 1
                index += 1
            row += 1

        # Draw Exit at the bottom
        mode = curses.A_REVERSE if index == selected else curses.A_NORMAL
        stdscr.addstr(row, 0, "-" * curses.COLS)
        stdscr.addstr(row + 1, 2, "[ Exit         ]", mode)
        stdscr.addstr(row + 1, 20, "Close ByteOS", mode)

        key = stdscr.getch()
        if key == curses.KEY_UP:
            selected = (selected - 1) % len(flat_items)
        elif key == curses.KEY_DOWN:
            selected = (selected + 1) % len(flat_items)
        elif key in [10, 13]:  # Enter
            stdscr.clear()
            flat_items[selected]["action"](stdscr)
        elif key == 27:  # ESC
            break
