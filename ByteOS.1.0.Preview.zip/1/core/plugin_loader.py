# core/plugin_loader.py
import os
import importlib.util

def load_plugins():
    plugins = []
    for filename in os.listdir("plugins"):
        if filename.endswith(".py"):
            path = os.path.join("plugins", filename)
            spec = importlib.util.spec_from_file_location(filename[:-3], path)
            module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(module)
            plugins.append(module)
    return plugins