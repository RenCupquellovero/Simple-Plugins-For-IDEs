# core/system.py
def initialize():
    print("[ByteOS] System initialized.")
