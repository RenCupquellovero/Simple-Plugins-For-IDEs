import curses
from core.main_menu import run_main_menu


curses.wrapper(run_main_menu)
