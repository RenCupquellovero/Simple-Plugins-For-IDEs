# plugins/plugin_store.py
import requests

PLUGIN_ID = "plugin_store"
PLUGIN_NAME = "Plugin Store"
PLUGIN_DESC = "Browse and install plugins from the ByteOS repo"

REPO_URL = "https://raw.githubusercontent.com/RenCupquellovero/Simple-Plugins-For-IDEs/main/plugin_index.json"

def run(stdscr):
    import curses
    import requests
    import json
    import os

    curses.curs_set(0)
    stdscr.nodelay(False)

    def fetch_plugins():
        try:
            res = requests.get(REPO_URL)
            if res.status_code == 200:
                return res.json()
        except:
            return []
        return []

    def install_plugin(plugin):
        try:
            res = requests.get(plugin["source_url"])
            if res.status_code == 200:
                with open(f"plugins/{plugin['plugin_id']}.py", "w") as f:
                    f.write(res.text)
                # Update registry
                registry_path = "plugins/registry.json"
                if os.path.exists(registry_path):
                    with open(registry_path, "r") as f:
                        registry = json.load(f)
                else:
                    registry = {"installed": []}
                if plugin["plugin_id"] not in registry["installed"]:
                    registry["installed"].append(plugin["plugin_id"])
                    with open(registry_path, "w") as f:
                        json.dump(registry, f, indent=2)
                return True
        except:
            return False
        return False

    plugins = fetch_plugins()
    selected = 0

    while True:
        stdscr.clear()
        stdscr.addstr(0, 0, "🛒 ByteOS Plugin Store", curses.A_BOLD)
        stdscr.addstr(1, 0, "Browse and install plugins from the official repo")
        stdscr.addstr(2, 0, "-" * curses.COLS)
        if not plugins:
            stdscr.clear()
            stdscr.addstr(0, 0, "🛒 ByteOS Plugin Store", curses.A_BOLD)
            stdscr.addstr(2, 0, "No plugins found in the index.")
            stdscr.addstr(4, 0, "Press Q to quit or R to refresh.")
            stdscr.refresh()
            key = stdscr.getch()
            if key in [ord('r'), ord('R')]:
                plugins = fetch_plugins()
            elif key in [ord('q'), ord('Q')]:
                return
            continue


        for i, plugin in enumerate(plugins):
            mode = curses.A_REVERSE if i == selected else curses.A_NORMAL
            label = f"[ {plugin['name']:<15} ]"
            desc = plugin.get("description", "")
            stdscr.addstr(4 + i, 2, label, mode)
            stdscr.addstr(4 + i, 22, desc, mode)

        stdscr.addstr(curses.LINES - 3, 0, "-" * curses.COLS)
        stdscr.addstr(curses.LINES - 2, 2, "Enter = Install | R = Refresh | Q = Quit")

        key = stdscr.getch()
        if key == curses.KEY_UP:
            selected = (selected - 1) % len(plugins)
        elif key == curses.KEY_DOWN:
            selected = (selected + 1) % len(plugins)
        elif key in [10, 13]:  # Enter
            stdscr.clear()
            stdscr.addstr(0, 0, f"Installing {plugins[selected]['name']}...")
            stdscr.refresh()
            success = install_plugin(plugins[selected])
            msg = "✅ Installed successfully!" if success else "❌ Failed to install."
            stdscr.addstr(2, 0, msg)
            stdscr.addstr(4, 0, "Press any key to continue.")
            stdscr.getch()
        elif key in [ord('r'), ord('R')]:
            plugins = fetch_plugins()
        elif key in [ord('q'), ord('Q')]:
            break
